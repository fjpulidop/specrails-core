# Getting Started

Get SpecRails running in your project in under 5 minutes.

## What is SpecRails?

SpecRails installs a **product-driven development workflow** into any
repository. It gives Claude Code, Codex CLI, Gemini CLI, or Kimi Code a team of
specialized AI roles — an architect, developers, layer reviewers, a reviewer,
and a product manager — that work together to go from idea to shipped PR
automatically.

Think of it as hiring a full engineering team that lives inside your CLI.

## Prerequisites

You need:

- **Git** — your project must be a git repository
- One supported AI CLI: Claude Code, Codex CLI, Gemini CLI, or Kimi Code

Optional (recommended):

- **[GitHub CLI](https://cli.github.com/)** (`gh`) — for automatic PR creation and issue tracking

See the [Codex guide](user-docs/getting-started-codex.md) or
[Kimi guide](user-docs/getting-started-kimi.md) for provider-specific setup.

## Install

**Plugin method (recommended) — no Node.js required**

```bash
claude plugin install sr
```

**Scaffold method (all providers, or full offline control)**

```bash
npx specrails-core@latest init --root-dir <your-project>
```

See [installation.md](installation.md) for full details on both methods and when to use each.

## Installation Tiers

### Quick Install (default via TUI)

When you run `npx specrails-core@latest init`, the TUI installer lets you choose **Quick** tier. This places agents, commands, rules, and settings directly — no AI interaction required:

1. Select agents to install
2. Choose a model preset
3. Provide a brief product description

Agents are ready to use immediately after install. Open the selected provider
CLI and start working.

> Quick install excludes VPC personas and persona-dependent agents/commands (sr-product-manager, sr-product-analyst). These require the full enrichment process.

### Full Install (via `/specrails:enrich`)

For deeper customization, choose **Full** tier or run `/specrails:enrich` after a Quick install:

```
/specrails:enrich
```

The full 5-phase wizard provides deep stack analysis, researched user personas, and fully adapted agents:

| Phase | What happens |
|-------|-------------|
| **1. Analyze** | Detects your tech stack, architecture layers, CI commands, and conventions |
| **2. Personas** | Researches your competitive landscape and generates full VPC user personas |
| **3. Configure** | Asks about your backlog provider, git workflow, and which agents to enable |
| **4. Generate** | Generates your project data files (`.specrails/`) with project-specific context |
| **5. Cleanup** | Removes the wizard scaffolding, leaving only your tailored workflow files |

Full install adds VPC personas, sr-product-manager, sr-product-analyst, and persona-dependent commands.

After either tier, your `/specrails:*` commands are live.

## Your first feature

Let's implement something. Pick an issue from your backlog, or describe a feature:

```
/specrails:implement "add a health check endpoint"
```

SpecRails will:

1. **Architect** analyzes the request and designs the implementation
2. **Developer** writes the code across all layers
3. **Test Writer** generates tests for the new code
4. **Doc Sync** updates your changelog and docs
5. **Security Reviewer** scans for secrets and vulnerabilities
6. **Reviewer** runs your full CI suite and fixes any issues
7. Creates a **Pull Request** ready for human review

That's it. One command, full pipeline.

## Useful commands for newcomers

Once you have a feature running, a few commands help you understand what's happening and why:

- `/specrails:why "question"` — search agent explanation records in plain language. Ask why a design decision was made, why a library was chosen, or why a particular pattern is used. Agents record their reasoning as they work.
- `/specrails:get-backlog-specs` — see your prioritized backlog with safe implementation ordering. Good first stop before picking what to build next.
- `/specrails:compat-check #N` — check whether an issue's implementation would break existing API consumers before you commit to it.

## What's next?

Now that you're running, learn how the system thinks:

- [Core Concepts](concepts.md) — understand the pipeline architecture and product-driven approach
- [Agents](agents.md) — meet each agent and understand their role
- [Workflows & Commands](workflows.md) — master the full command set

---

**Looking for step-by-step guides?** See [Quick Start](user-docs/quick-start.md) for a walkthrough of your first feature, or [Installation](user-docs/installation.md) for detailed install options including Codex support.

[← Back to Docs](README.md) · [Core Concepts →](concepts.md)
